<?php

namespace App\Http\Controllers\menu;

use App\Http\Controllers\Controller;
use App\Models\Datausaha;
use App\Models\Periode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Calculation\DateTimeExcel\Month;

class DashboardController extends Controller
{
    public function index()
    {
        $totalUsaha = Datausaha::count();

        // Pendapatan Start
        $pembelian = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('pembelians', 'periodes.id', '=', 'pembelians.periode_id')
            ->select([
                DB::raw('sum(total_biaya) as total_beli'),
            ])
            ->get();
        $penjualan = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('penjualans', 'periodes.id', '=', 'penjualans.periode_id')
            ->select([
                DB::raw('sum(total_jual) as total_jual'),
            ])
            ->get();
        $pendapatan = $penjualan->sum('total_jual') - $pembelian->sum('total_beli');

        // Pengeluaran
        $biaya = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('biayas', 'periodes.id', '=', 'biayas.periode_id')
            ->select([
                DB::raw('sum(jumlah_biaya) as jumlah_biaya'),
            ])
            ->get();
        $gaji = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('gajis', 'periodes.id', '=', 'gajis.periode_id')
            ->select([
                DB::raw('sum(gaji) as gaji'),
            ])
            ->get();
        $pengeluaran = $biaya->sum('jumlah_biaya') + $gaji->sum('gaji');

        // Laba Bersih
        $labaBersih = $pendapatan - $pengeluaran;

        $bulan = \Carbon\Carbon::parse(date(now()))->isoFormat('MMMM');
        $tahun = \Carbon\Carbon::parse(date(now()))->isoFormat('Y');

        // Chart Tonase Beli
        $tonBeli = [];
        $tonaseBeli = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('pembelians', 'periodes.id', '=', 'pembelians.periode_id')
            ->select([
                DB::raw('sum(total_tonase) as tonase_beli'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->whereMonth('tanggal_awal', '=', now())->whereYear('tanggal_awal', '=', now())
            ->get();

        // Chart Tonase Jual
        $tonJual = [];
        $tonaseJual = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('penjualans', 'periodes.id', '=', 'penjualans.periode_id')
            ->select([
                DB::raw('sum(tonase_jual) as tonase_jual'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->whereMonth('tanggal_awal', '=', now())->whereYear('tanggal_awal', '=', now())
            ->get();

        // passing chart beli
        foreach ($tonaseBeli as $item) {
            $tonBeli[] = $item->tonase_beli;
        }

        // passing chart jual
        foreach ($tonaseJual as $item) {
            $tonJual[] = $item->tonase_jual;
        }

        // Chart Pembelian Produksi
        $beliP = [];
        $beliProduksi = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('pembelians', 'periodes.id', '=', 'pembelians.periode_id')
            ->select([
                DB::raw('sum(total_biaya) as beli_produksi'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->whereMonth('tanggal_awal', '=', now())->whereYear('tanggal_awal', '=', now())
            ->get();

        // passing chart Pembelian Produksi
        foreach ($beliProduksi as $item) {
            $beliP[] = $item->beli_produksi;
        }

        // Chart Penjualan Produksi
        $jualP = [];
        $jualProduksi = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('penjualans', 'periodes.id', '=', 'penjualans.periode_id')
            ->select([
                DB::raw('sum(total_jual) as jual_produksi'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->whereMonth('tanggal_awal', '=', now())->whereYear('tanggal_awal', '=', now())
            ->get();

        // passing chart Penjualan Produksi
        foreach ($jualProduksi as $item) {
            $jualP[] = $item->jual_produksi;
        }


        // dd(json_encode($jualP));


        // dd($tonJual);

        return view("menu.dashboard.index", compact(
            'totalUsaha',
            'pendapatan',
            'pengeluaran',
            'labaBersih',

            'bulan',
            'tahun',

            'tonaseBeli',
            'tonBeli',
            'tonaseJual',
            'tonJual',

            'beliProduksi',
            'beliP',
            'jualProduksi',
            'jualP'
        ));
    }
}
