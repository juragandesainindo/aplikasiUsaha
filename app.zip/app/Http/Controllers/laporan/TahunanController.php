<?php

namespace App\Http\Controllers\laporan;

use App\Http\Controllers\Controller;
use App\Models\Datausaha;
use App\Models\Periode;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use DivisionByZeroError;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TahunanController extends Controller
{
    public function index()
    {
        $usaha = Datausaha::all();
        return view('laporan.tahunan.index', compact('usaha'));
    }

    public function show(Request $request, $id)
    {
        $usaha = Datausaha::findOrFail($id);

        $year   = $request->input('year');
        $usahaId = $request->input('usahaId');

        $periode = Periode::select()
            ->where('datausaha_id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        // dd($periode);

        $tonaseBeli = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('pembelians', 'periodes.id', '=', 'pembelians.periode_id')
            ->select([
                DB::raw('sum(total_tonase) as tonase_beli'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();
        // dd($tonaseBeli);

        $tonaseJual = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('penjualans', 'periodes.id', '=', 'penjualans.periode_id')
            ->select([
                DB::raw('sum(tonase_jual) as tonase_jual'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $totalBeli = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('pembelians', 'periodes.id', '=', 'pembelians.periode_id')
            ->select([
                DB::raw('sum(total_biaya) as total_biaya'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $totalJual = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('penjualans', 'periodes.id', '=', 'penjualans.periode_id')
            ->select([
                DB::raw('sum(total_jual) as total_jual'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $biaya = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('biayas', 'periodes.id', '=', 'biayas.periode_id')
            ->select([
                DB::raw('sum(jumlah_biaya) as jumlah_biaya'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $gaji = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('gajis', 'periodes.id', '=', 'gajis.periode_id')
            ->select([
                DB::raw('sum(gaji) as upah'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $sisaJual = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('sisaproduksis', 'periodes.id', '=', 'sisaproduksis.periode_id')
            ->select([
                DB::raw('sum(tonase_sisa_terjual) as tonase_sisa_terjual'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();


        $pendatapan = $totalJual->sum('total_jual') - $totalBeli->sum('total_biaya');
        $operasional = $biaya->sum('jumlah_biaya') + $gaji->sum('upah');
        $total = $pendatapan - $operasional;
        $selisih = $tonaseJual->sum('tonase_jual') - $tonaseBeli->sum('tonase_beli');
        $terjualLagi = $sisaJual->sum('tonase_sisa_terjual');
        $sortir = $selisih + $terjualLagi;

        try {
            $hargaRataJual = $totalJual->sum('total_jual') / $tonaseJual->sum('tonase_jual');
            $hargaRataBeli = $totalBeli->sum('total_biaya') / $tonaseBeli->sum('tonase_beli');
            $selisihJual = $hargaRataJual - $hargaRataBeli;
            $selisihHarga = $selisih * $hargaRataJual;
        } catch (\Throwable $th) {
            $hargaRataJual = 0;
            $hargaRataBeli = 0;
            $selisihJual = 0;
            $selisihHarga = 0;
        }

        // dd($hargaRataJual);



        return view('laporan.tahunan.show', compact(
            'usaha',
            'periode',
            'year',
            'tonaseBeli',
            'tonaseJual',
            'totalBeli',
            'totalJual',
            'biaya',
            'gaji',
            'sisaJual',
            'pendatapan',
            'operasional',
            'total',
            'selisih',
            'terjualLagi',
            'sortir',
            // keterangan
            'hargaRataJual',
            'hargaRataBeli',
            'selisihJual',
            'selisihHarga'
        ));
    }

    public function cetak(Request $request, $id)
    {
        $usaha = Datausaha::findOrFail($id);

        $year   = $request->input('year');
        $usahaId = $request->input('usahaId');

        $periode = Periode::select()
            ->where('datausaha_id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        // ############################# JANUARI START #############################
        $tonaseBeli = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('pembelians', 'periodes.id', '=', 'pembelians.periode_id')
            ->select([
                DB::raw('sum(total_tonase) as tonase_beli'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $tonaseJual = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('penjualans', 'periodes.id', '=', 'penjualans.periode_id')
            ->select([
                DB::raw('sum(tonase_jual) as tonase_jual'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();
        $totalBeli = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('pembelians', 'periodes.id', '=', 'pembelians.periode_id')
            ->select([
                DB::raw('sum(total_biaya) as total_biaya'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();
        $totalJual = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('penjualans', 'periodes.id', '=', 'penjualans.periode_id')
            ->select([
                DB::raw('sum(total_jual) as total_jual'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $biaya = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('biayas', 'periodes.id', '=', 'biayas.periode_id')
            ->select([
                DB::raw('sum(jumlah_biaya) as jumlah_biaya'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $gaji = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('gajis', 'periodes.id', '=', 'gajis.periode_id')
            ->select([
                DB::raw('sum(gaji) as upah'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $sisaJual = Datausaha::join('periodes', 'datausahas.id', '=', 'periodes.datausaha_id')
            ->join('sisaproduksis', 'periodes.id', '=', 'sisaproduksis.periode_id')
            ->select([
                DB::raw('sum(tonase_sisa_terjual) as tonase_sisa_terjual'),
                DB::raw('EXTRACT(MONTH from tanggal_awal) as bulan'),
                DB::raw('EXTRACT(YEAR from tanggal_awal) as tahun')
            ])
            ->groupBy(['bulan', 'tahun'])
            ->where('datausahas.id', '=', $usahaId)
            ->whereYear('tanggal_awal', '=', $year)
            ->get();

        $pendatapan = $totalJual->sum('total_jual') - $totalBeli->sum('total_biaya');
        $operasional = $biaya->sum('jumlah_biaya') + $gaji->sum('upah');
        $total = $pendatapan - $operasional;
        $selisih = $tonaseJual->sum('tonase_jual') - $tonaseBeli->sum('tonase_beli');
        $terjualLagi = $sisaJual->sum('tonase_sisa_terjual');
        $sortir = $selisih + $terjualLagi;

        try {
            $hargaRataJual = $totalJual->sum('total_jual') / $tonaseJual->sum('tonase_jual');
            $hargaRataBeli = $totalBeli->sum('total_biaya') / $tonaseBeli->sum('tonase_beli');
            $selisihJual = $hargaRataJual - $hargaRataBeli;
            $selisihHarga = $selisih * $hargaRataJual;
        } catch (\Throwable $th) {
            $hargaRataJual = 0;
            $hargaRataBeli = 0;
            $selisihJual = 0;
            $selisihHarga = 0;
        }


        $cetak = Pdf::loadview('laporan.tahunan.cetak', compact(
            'usaha',
            'periode',
            'year',
            'tonaseBeli',
            'tonaseJual',
            'totalBeli',
            'totalJual',
            'biaya',
            'gaji',
            'sisaJual',

            'pendatapan',
            'operasional',
            'total',
            'selisih',
            'terjualLagi',
            'sortir',
            // keterangan
            'hargaRataJual',
            'hargaRataBeli',
            'selisihJual',
            'selisihHarga'

        ))->setPaper('a4', 'landscape');
        return $cetak->stream('laporan tahunan');
    }
}